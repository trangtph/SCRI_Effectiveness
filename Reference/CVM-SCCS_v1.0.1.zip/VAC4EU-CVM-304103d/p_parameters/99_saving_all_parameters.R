save.image(file = paste0(dirpargen, "parameters.RData"))

# rm(list=ls(all.names=TRUE))
# 
# thisdir<-setwd(dirname(rstudioapi::getSourceEditorContext()$path))
# thisdir<-setwd(dirname(rstudioapi::getSourceEditorContext()$path))
# source(paste0(thisdir, "/p_macro/", "launch_step.R"))
