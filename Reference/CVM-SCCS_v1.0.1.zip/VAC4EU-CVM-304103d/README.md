# CVM

See the [wiki](https://github.com/VAC4EU/CVM/wiki/) of this repository for a detailed explanation. The data included in this page are fictitious and included for illustration purposes only. 
